# Seu Novo Lar

Marketplace imobiliário (Angola). Site estático ligado ao Supabase.

- `index.html`: o site completo (publicar no GitHub Pages).
- `schema.sql`: esquema da base de dados; correr no SQL Editor do Supabase.
- `.nojekyll`: indica ao GitHub Pages para servir os ficheiros tal como estão.

Nota: o URL e a chave publicável do Supabase estão no início do script de `index.html`. Nunca coloques aqui a chave secreta.
